package conversorMoedas;

import javax.swing.JOptionPane;

public class Principal {

	public static void main(String[] args) {
		JanelaOpcoes p = new JanelaOpcoes();
		boolean chamaNovamente = p.chamaOpcoes();
		if (chamaNovamente == true) {
			p.chamaOpcoes();
		} 
	}
}
