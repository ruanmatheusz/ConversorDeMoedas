package conversorMoedas;

import javax.swing.JOptionPane;

public class JanelaOpcoes {

	public static Funcao moedas = new Funcao();
	public static Funcao temperatura = new Funcao();

	public boolean chamaOpcoes() {

		String opcoes = JOptionPane.showInputDialog(null, "Escolha uma opção", "Menu", JOptionPane.PLAIN_MESSAGE, null,
				new Object[] { "Conversor de Moeda", "Conversor de Temperatura" }, "Escolha").toString();
		switch (opcoes) {
		case "Conversor de Moeda":
			String input = JOptionPane.showInputDialog("Insira um valor");
			double valorRecebido = Double.parseDouble(input);
			moedas.ConverterMoedas(valorRecebido);

			int resposta = JOptionPane.showConfirmDialog(null, "Deseja continuar?");
			if (JOptionPane.OK_OPTION == resposta) {
				return true;
			} else {
				JOptionPane.showMessageDialog(null, "Programa Finalizado");
				break;
			}

		case "Conversor de Temperatura":
			String inputTemperatura = JOptionPane.showInputDialog("Insira um valor");
			double temperaturaRecebida = Double.parseDouble(inputTemperatura);
			temperatura.ConverterTemperatura(temperaturaRecebida);

			int respostaTemperatura = JOptionPane.showConfirmDialog(null, "Deseja continuar?");
			if (JOptionPane.OK_OPTION == respostaTemperatura) {
				return true;
			} else {
				JOptionPane.showMessageDialog(null, "Programa Finalizado");
				break;
			}
			
		}
		return false;
	}
}
