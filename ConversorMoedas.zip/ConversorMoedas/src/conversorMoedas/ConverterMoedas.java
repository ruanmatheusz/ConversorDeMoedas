package conversorMoedas;

import javax.swing.JOptionPane;

public class ConverterMoedas {
	
	public void ConverterReaisADolar(double d) {
		double moedaDolar = d / 5.23;
		moedaDolar = (double) Math.round(moedaDolar * 100d) / 100;
		JOptionPane .showMessageDialog(null,"Você tem $ " + moedaDolar + " Dólares");
		
	}
	
	public void ConverterReaisAEuro(double d) {
		double moedaEuro = d / 5.57;
		moedaEuro = (double) Math.round(moedaEuro * 100d) / 100;
		JOptionPane .showMessageDialog(null,"Você tem $ " + moedaEuro + " Euros");
		
	}
	
	public void ConverterReaisALibras(double d) {
		double moedaLibra = d / 6.32;
		moedaLibra = (double) Math.round(moedaLibra * 100d) / 100;
		JOptionPane .showMessageDialog(null,"Você tem $ " + moedaLibra + " Libras");
		
	}
	
	public void ConverterReaisAPesoArgentino(double d) {
		double moedaArgentina = d / 0.027;
		moedaArgentina = (double) Math.round(moedaArgentina * 1000d) / 1000;
		JOptionPane .showMessageDialog(null,"Você tem $ " + moedaArgentina + " Pesos Argentinos");
	}
		
	public void ConverterReaisAPesoChileno(double d) {
			double moedaChilena = d / 0.027;
			moedaChilena = (double) Math.round(moedaChilena * 1000d) / 1000;
			JOptionPane .showMessageDialog(null,"Você tem $ " + moedaChilena + " Pesos Chilenos");
		
	}
	
	public void ConverterDolarAReais(double d) {
		double moedaReal = d / 0.19;
		moedaReal = (double) Math.round(moedaReal * 100d) / 100;
		JOptionPane .showMessageDialog(null,"Você tem $ " + moedaReal + " Reais");
		
	}
	
	public void ConverterEuroAReais(double d) {
		double moedaReal = d / 0.18;
		moedaReal = (double) Math.round(moedaReal * 100d) / 100;
		JOptionPane .showMessageDialog(null,"Você tem $ " + moedaReal + " Reais");
		
	}
	
	public void ConverterLibrasAReais(double d) {
		double moedaReal = d / 0.16;
		moedaReal = (double) Math.round(moedaReal * 100d) / 100;
		JOptionPane .showMessageDialog(null,"Você tem $ " + moedaReal + " Reais");
		
	}
	
	public void ConverterPesoArgentinoAReais(double d) {
		double moedaReal = d / 36.97;
		moedaReal = (double) Math.round(moedaReal * 100d) / 100;
		JOptionPane .showMessageDialog(null,"Você tem $ " + moedaReal + " Reais");
		
	}
	
	public void ConverterPesoChilenoAReais(double d) {
		double moedaReal = d / 151.62;
		moedaReal = (double) Math.round(moedaReal * 100d) / 100;
		JOptionPane .showMessageDialog(null,"Você tem $ " + moedaReal + " Reais");
		
	}
}
