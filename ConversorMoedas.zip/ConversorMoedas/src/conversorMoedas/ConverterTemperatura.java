package conversorMoedas;

import javax.swing.JOptionPane;

public class ConverterTemperatura {
	
		public void converterGrausEmF (double temperatura) {
			double temperaturaConvertida = ((temperatura * 9) / 5) + 32;
			temperaturaConvertida = (double) Math.round(temperaturaConvertida * 100d) / 100;
			JOptionPane .showMessageDialog(null,"Você tem  " + temperaturaConvertida + " F");
		}
		
		public void converterFEmGraus (double temperatura) {
			double temperaturaConvertida = ((temperatura - 32) * 5) / 9;
			temperaturaConvertida = (double) Math.round(temperaturaConvertida * 100d) / 100;
			JOptionPane .showMessageDialog(null,"Você tem  " + temperaturaConvertida + " C");
		}
}
