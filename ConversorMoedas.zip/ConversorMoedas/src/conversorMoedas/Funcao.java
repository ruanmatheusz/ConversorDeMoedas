package conversorMoedas;

import javax.swing.JOptionPane;

public class Funcao {

	ConverterMoedas moedas = new ConverterMoedas();
	ConverterTemperatura temperatura = new ConverterTemperatura();

	public void ConverterMoedas(double valorRecebido) {
		String opcao = (JOptionPane.showInputDialog(null,
				"Escolha a moeda para a qual você dseja converter seu dinheiro ", "Moedas", JOptionPane.PLAIN_MESSAGE,
				null,
				new Object[] { "De Reais a Dólares", "De Reais a Euros", "De Reais a Libras",
						"De Reais a Peso Argentino", "De Reais a Peso Chileno", "De Dólares a Reais",
						"De Euros a Reais", "De Libras a Reais", "De Peso Argentino a Reais",
						"De Peso Chileno a Reais" },
				null)).toString();
		switch (opcao) {
		case "De Reais a Dólares":
			moedas.ConverterReaisADolar(valorRecebido);
			break;
		case "De Reais a Euros":
			moedas.ConverterReaisAEuro(valorRecebido);
			break;
		case "De Reais a Libras":
			moedas.ConverterReaisALibras(valorRecebido);
			break;
		case "De Reais a Peso Argentino":
			moedas.ConverterReaisAPesoArgentino(valorRecebido);
			break;
		case "De Reais a Peso Chileno":
			moedas.ConverterReaisAPesoChileno(valorRecebido);
			break;
		case "De Dólares a Reais":
			moedas.ConverterDolarAReais(valorRecebido);
			break;
		case "De Euros a Reais":
			moedas.ConverterEuroAReais(valorRecebido);
			break;
		case "De Libras a Reais":
			moedas.ConverterLibrasAReais(valorRecebido);
			break;
		case "De Peso Argentino a Reais":
			moedas.ConverterPesoArgentinoAReais(valorRecebido);
			break;
		case "De Peso Chileno a Reais":
			moedas.ConverterPesoChilenoAReais(valorRecebido);
			break;
		}

	}

	public void ConverterTemperatura(double valorRecebido) {
		String opcao = (JOptionPane.showInputDialog(null, "Escolha a temperatura para a qual você dseja converter ",
				"Temperatura", JOptionPane.PLAIN_MESSAGE, null,
				new Object[] { "De Graus para Fahrenheit", "De Fahrenheit para Graus" }, null)).toString();
		switch (opcao) {
		case "De Graus para Fahrenheit":
			temperatura.converterGrausEmF(valorRecebido);
			break;
		case "De Fahrenheit para Graus":
			temperatura.converterFEmGraus(valorRecebido);
			break;
		}
	}
}
